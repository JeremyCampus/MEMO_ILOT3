console.log("exercice 7");

function getData() {
  return data; // data is defined in DATA.js file
}