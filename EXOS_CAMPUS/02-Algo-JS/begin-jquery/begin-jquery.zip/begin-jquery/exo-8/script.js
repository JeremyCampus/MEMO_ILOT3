console.log("exercice 8");
