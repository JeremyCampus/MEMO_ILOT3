console.log("exercice 4");
