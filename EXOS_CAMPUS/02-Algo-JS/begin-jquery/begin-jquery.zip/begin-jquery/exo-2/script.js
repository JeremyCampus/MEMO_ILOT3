console.log('exercice 2');

