console.log("exercice 5");
