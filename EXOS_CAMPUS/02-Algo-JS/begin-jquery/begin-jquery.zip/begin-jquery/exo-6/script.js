console.log("exercice 6");
