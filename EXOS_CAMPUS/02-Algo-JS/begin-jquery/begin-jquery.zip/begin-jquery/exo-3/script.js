console.log("exercice 3");
